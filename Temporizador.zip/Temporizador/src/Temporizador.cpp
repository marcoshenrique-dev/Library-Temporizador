#include "Temporizador.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "Arduino.h"

Temporizador::Temporizador(String Hora1 , String Hora2 , String Hora3){

     Horario1 = Hora1;

     Horario2 = Hora2;

     Horario3 = Hora3;

      Horarios[0] = Hora1;

       Horarios[1] = Hora2;

        Horarios[2] = Hora3;





}


bool Temporizador::Verificador (String Hora_atual){


hora_atual = Hora_atual;



 if(hora_atual == Horarios[0] || hora_atual == Horarios[1] || hora_atual == Horarios[2]){

      return true;
     }else{

      return false;
     }




}
