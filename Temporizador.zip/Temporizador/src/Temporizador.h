#ifndef Temporizador_h
#define Temporizador_h

#include "Arduino.h"


class Temporizador {



private :

      String Horario1;

      String Horario2;

      String Horario3;

      String Horarios[3];

      String hora_atual;


public :







  Temporizador(String Hora1 , String Hora2 , String Hora3  );

  bool Verificador (String Hora_atual);


};


#endif
